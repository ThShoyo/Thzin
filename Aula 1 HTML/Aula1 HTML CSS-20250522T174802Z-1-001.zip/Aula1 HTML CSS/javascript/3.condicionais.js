const idade = 18

if (idade < 18) {
    console.log("Menor de idade")
} else {
    console.log("Maior de idade")
}