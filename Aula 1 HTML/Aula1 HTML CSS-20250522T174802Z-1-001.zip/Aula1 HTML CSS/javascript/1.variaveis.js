// os comandos 'var' e 'let' servem para criar variaveis
let nome = 'Marta'
var sexo = "feminino"
// exibindo
console.log('Nome: ', nome)
console.log (`Sexo: ${sexo}`)