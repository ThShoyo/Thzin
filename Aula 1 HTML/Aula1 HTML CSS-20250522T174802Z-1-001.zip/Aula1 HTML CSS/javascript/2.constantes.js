
// constantes
const idade = 20

// Tentando mudar a idade
// idade = 1 / Constante não muda

// exibindo
console.log('Idade: ', idade)
console.log (`minha idade: ${idade}`)
