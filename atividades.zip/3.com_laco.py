import os

os.system("cls || clear")

print("SOLICITANDO AS NOTAS")
for i in range(3):
    nota = int(input(f"Digite a {(i+1)}ª nota: "))
    print("...")
    print("...")
    print("...")
    print("...")

    
print("FIM DO PROGRAMA")