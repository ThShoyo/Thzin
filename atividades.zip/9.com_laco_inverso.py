import os

os.system("cls || clear")


print ("APENAS OS NÚMERO ÍMPARES")

for i in range(1,22):
    if i % 2 == 1:
        print(i)

print("FIM DO PROGRAMA")