import os

os.system("cls || clear")

print("INÍCIO DO PROGRAMA")
for i in range(1,6):
    print(f"Valor da variável: {i}")

print("FIM DO PROGRAMA")