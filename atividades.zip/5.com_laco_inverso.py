import os
import time

os.system("cls || clear")

print("CONTAGEM REGRESSIVA")
for i in range(5,0,-1):
    print(f"Valor da variável i: {i}")
    time.sleep(1)

print("FIM DO PROGRAMA")