import os 

os.system("cls || clear")

print ("APENAS OS NÚMERO PARES")

for i in range(100,121,2):
    print(i)

print("FIM DO PROGRAMA")